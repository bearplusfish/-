int main() {

    *((char *)0x0800) = 'H';

    return 0;
}